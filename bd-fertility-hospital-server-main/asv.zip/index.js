const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const featureRoute = require("./src/Module/Features/featureRoute.js");
const doctorRoute = require("./src/Module//Doctors/doctorsRoute.js");
const usersRoute = require("./src/Module/Users/userRoute");
const blogRoute = require("./src/Module/Blog/blogRoute.js");
const allGalleryRoute = require("./src/Module/Gallery/galleryRoute.js");

const app = express();
const port = 5000;

app.use(express.json());
app.use(cors());

// Database connection
mongoose
  .connect(
    "mongodb+srv://test-demo-database:test-demo-database@cluster0.5tlwrug.mongodb.net/hospital?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("Database connection is successful 🛢");
  })
  .catch((error) => {
    console.error("Error connecting to the database:", error.message);
  });

app.use("/bd-fertility", featureRoute); // Use the router directly
app.use("/doctor-route", doctorRoute); // Use the router directly
app.use("/user-route", usersRoute); // Use the router directly
app.use("/blog-route", blogRoute); // Use the router directly
app.use("/Gallery-route", allGalleryRoute); // Use the router directly

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
